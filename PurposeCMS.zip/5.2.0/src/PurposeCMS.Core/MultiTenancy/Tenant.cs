﻿using Abp.MultiTenancy;
using PurposeCMS.Authorization.Users;

namespace PurposeCMS.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
