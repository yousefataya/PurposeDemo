﻿namespace PurposeCMS
{
    public class PurposeCMSConsts
    {
        public const string LocalizationSourceName = "PurposeCMS";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
